#!/bin/bash

Device=0
model_root=/home/xxx/GraTa/GraTa-master/models
data_root=/home/xxx/GraTa/GraTa-master/dataset
Aux=ent
Pse=consis

# 不同的 batch size 实验列表
BATCH_SIZES=(1)
# 高维特征一致性 loss 权重列表
FEAT_WEIGHTS=(0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.11 0.12 0.13 0.14 0.15 0.16 0.17 0.18 0.19 0.2 0.21 0.22 0.23 0.94 0.95 0.96 0.97 0.98 0.9  9 1.0)

# 保存每个组合输出的日志目录
OUT_DIR=./exp_runs
mkdir -p "$OUT_DIR"

PIDS=()
MAX_JOBS=12  # 同时最多并行实验数
JOB_COUNT=0

# 启动所有组合的实验（分批并行运行，每批最多 MAX_JOBS 个）
# for Source in RIM_ONE_r3 REFUGE ORIGA REFUGE_Valid Drishti_GS
for Source in Drishti_GS
do
  echo "=============================="
  echo "Source: $Source"
  for BS in "${BATCH_SIZES[@]}"
  do
    for FW in "${FEAT_WEIGHTS[@]}"
    do
      LOG_FILE="${OUT_DIR}/${Source}_bs${BS}_fw${FW}.log"
      echo "Launching: Source=$Source, BatchSize=$BS, FeatLossWeight=$FW -> $LOG_FILE"
      python TTA.py \
        --Source_Dataset $Source \
        --aux_loss $Aux \
        --pse_loss $Pse \
        --batch_size $BS \
        --feat_loss_weight $FW \
        --path_save_model $model_root \
        --dataset_root $data_root > "$LOG_FILE" 2>&1 &
      PIDS+=($!)
      JOB_COUNT=$((JOB_COUNT+1))

      # 如果达到最大并行数，则等待当前这一批全部结束
      if [ "$JOB_COUNT" -ge "$MAX_JOBS" ]; then
        echo "Reached MAX_JOBS=$MAX_JOBS, waiting for current batch to finish..."
        for pid in "${PIDS[@]}"; do
          wait "$pid"
        done
        PIDS=()
        JOB_COUNT=0
      fi
    done
  done
done

# 等待最后一批未满 MAX_JOBS 的实验结束
for pid in "${PIDS[@]}"; do
  wait "$pid"
done

echo ""
echo "================ SUMMARY (by log files in $OUT_DIR) ================"

# 汇总每个组合的 Dice Mean
for Source in RIM_ONE_r3 REFUGE ORIGA REFUGE_Valid Drishti_GS
do
  for BS in "${BATCH_SIZES[@]}"
  do
    for FW in "${FEAT_WEIGHTS[@]}"
    do
      LOG_FILE="${OUT_DIR}/${Source}_bs${BS}_fw${FW}.log"
      if [ -f "$LOG_FILE" ]; then
        SCORE_LINE=$(grep "Dice Mean=" "$LOG_FILE" | tail -n 1)
        if [ -n "$SCORE_LINE" ]; then
          SCORE=${SCORE_LINE#*=}
          echo "Source=$Source, BS=$BS, FW=$FW, DiceMean=$SCORE"
        else
          echo "Source=$Source, BS=$BS, FW=$FW, DiceMean=NA (no score found)"
        fi
      else
        echo "Source=$Source, BS=$BS, FW=$FW, DiceMean=NA (log missing)"
      fi
    done
  done
done

