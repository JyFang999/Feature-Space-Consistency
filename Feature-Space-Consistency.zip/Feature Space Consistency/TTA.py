import torch
import os
os.environ["CUDA_VISIBLE_DEVICES"] = '0'
from networks.ResUnet import ResUnet
from config import *
from utils.metrics import calculate_metrics
import numpy as np
import argparse
import sys, datetime, time
from torch.utils.data import DataLoader
from dataloaders.OPTIC_dataloader import OPTIC_dataset
from dataloaders.convert_csv_to_list import convert_labeled_list
from dataloaders.transform import collate_fn_wo_transform
from custom_optimizers.grata import GraTa


torch.set_num_threads(1)


def print_information(config):
    print('Model Root: ', config.path_save_model)
    print('GPUs: ', torch.cuda.device_count())
    print('time: ', config.time_now)
    print('source domain: ', config.Source_Dataset)
    print('target domain: ', config.Target_Dataset)
    print('model: ' + str(config.model_type))

    print('input size: ', config.image_size)
    print('batch size: ', config.batch_size)

    print('optimizer: ', config.optimizer)
    print('lr: ', config.lr)

    print('auxiliary loss: ', config.aux_loss)
    print('pseudo loss: ', config.pse_loss)
    print('***' * 10)


def collect_params(model):
    """Collect the affine scale + shift parameters from *all* batch norms.

    这是原版 GraTa-TTA 的设置：对所有 BN 的 weight/bias 做 test-time 自适应。
    """
    params = []
    names = []
    for nm, m in model.named_modules():
        if isinstance(m, nn.BatchNorm2d):
            for np, p in m.named_parameters():
                if np in ['weight', 'bias']:  # weight is scale, bias is shift
                    params.append(p)
                    names.append(f"{nm}.{np}")
    return params


class TrainTTA:
    def __init__(self, config):
        config.time_now = datetime.datetime.now().__format__("%Y%m%d_%H%M%S_%f")
        self.load_model = os.path.join(config.path_save_model, str(config.Source_Dataset))  # Pretrained Source Model
        self.log_path = os.path.join(config.path_save_log, 'TrainTTA')  # Save Log

        if not os.path.exists(self.log_path):
            os.makedirs(self.log_path)

        self.log_path = os.path.join(self.log_path, config.time_now + '.log')
        sys.stdout = Logger(self.log_path, sys.stdout)

        # Data Loading
        target_test_csv = []
        if config.Target_Dataset != 'REFUGE_Valid':
            target_test_csv.append(config.Target_Dataset + '_train.csv')
            target_test_csv.append(config.Target_Dataset + '_test.csv')
        else:
            target_test_csv.append(config.Target_Dataset + '.csv')
        ts_img_list, ts_label_list = convert_labeled_list(config.dataset_root, target_test_csv)
        target_test_dataset = OPTIC_dataset(config.dataset_root, ts_img_list, ts_label_list,
                                            config.image_size, img_normalize=True)
        self.target_test_loader = DataLoader(dataset=target_test_dataset,
                                             batch_size=config.batch_size,
                                             shuffle=False,
                                             pin_memory=True,
                                             drop_last=False,
                                             collate_fn=collate_fn_wo_transform,
                                             num_workers=config.num_workers)

        # Model
        self.backbone = config.backbone
        self.in_ch = config.in_ch
        self.out_ch = config.out_ch
        self.image_size = config.image_size
        self.model_type = config.model_type

        # Optimizer
        self.optimizer = None
        self.optim = config.optimizer
        self.lr = config.lr
        self.momentum = config.momentum
        self.betas = (config.beta1, config.beta2)

        # Training
        self.device = config.device
        self.aux = config.aux_loss
        self.pse = config.pse_loss
        # 高维特征一致性 loss 权重
        self.feat_loss_weight = getattr(config, "feat_loss_weight", 0.0)
        # curriculum TTA 置信度阈值（<0 表示不启用）
        self.conf_thresh = getattr(config, "conf_thresh", -1.0)
        # 至少有多少比例的 batch 属于“高置信样本”，否则视为困难域，自动关闭难样本阶段
        self.min_easy_ratio = getattr(config, "min_easy_ratio", 0.0)

        # print_information(config)  # 不显示配置信息
        self.build_model()
        # self.print_network()  # 不显示参数数量

    def build_model(self):
        self.model = ResUnet(resnet=self.backbone, num_classes=self.out_ch, pretrained=False).to(self.device)
        checkpoint = torch.load(self.load_model + '/' + 'last-' + self.model_type + '.pth')
        self.model.load_state_dict(checkpoint, strict=False)

        para = collect_params(self.model)

        if self.optim == 'SGD':
            base_optimizer = torch.optim.SGD(
                para,
                lr=self.lr,
                momentum=self.momentum,
                nesterov=True,
            )
        elif self.optim == 'Adam':
            base_optimizer = torch.optim.Adam(
                para,
                lr=self.lr,
                betas=self.betas,
            )
        elif self.optim == 'AdamW':
            base_optimizer = torch.optim.AdamW(
                para,
                lr=self.lr,
                betas=self.betas,
            )
        else:
            raise NotImplementedError("ERROR: no such optimizer {}!".format(self.optim))
        self.optimizer = GraTa(para, base_optimizer, self.model, device=self.device, feat_loss_weight=getattr(self, "feat_loss_weight", 0.0))

    def print_network(self):
        num_params = 0
        for p in self.model.parameters():
            num_params += p.numel()
        print("The number of total parameters: {}".format(num_params))

    def run(self):
        metric_dict = ['Disc_Dice', 'Disc_ASSD', 'Cup_Dice', 'Cup_ASSD']

        total_batches = len(self.target_test_loader)
        easy_updates = 0
        run_hard_stage = True

        # ========= Curriculum TTA: Stage 1 (easy / high-confidence samples) / Stage 2 (hard samples) =========
        # 根据预测熵筛选样本，先用置信度高的一部分样本进行若干次更新；
        # 如果高置信样本比例过低（困难域），则自动跳过 Stage 2。
        for stage in [1, 2]:
            if self.conf_thresh < 0:
                # 未启用 curriculum，直接在 stage 1 跑一次原始 TTA
                if stage > 1:
                    break
            if stage == 2 and not run_hard_stage:
                # 对于高置信样本占比过低的困难域，自动关闭难样本阶段
                break

            for batch, data in enumerate(self.target_test_loader):
                x_np, y_np = data['data'], data['mask']
                x = torch.from_numpy(x_np).to(dtype=torch.float32).to(self.device)

                # 计算当前样本的预测熵，作为置信度度量
                with torch.no_grad():
                    pred_logit, _ = self.model(x)
                    pred_sigmoid = torch.sigmoid(pred_logit)
                    ent = -(pred_sigmoid * torch.log(pred_sigmoid + 1e-6)).mean()

                # curriculum 策略：
                #   stage 1: 只用 entropy < conf_thresh 的高置信度样本更新
                #   stage 2: 只用 entropy >= conf_thresh 的较难样本更新
                if self.conf_thresh >= 0:
                    if stage == 1 and ent >= self.conf_thresh:
                        continue
                    if stage == 2 and ent < self.conf_thresh:
                        continue

                self.model.train()
                self.model.requires_grad_(False)
                for nm, m in self.model.named_modules():
                    if self.aux in nm or self.pse in nm:
                        m.requires_grad_(True)
                    # 原版：所有 BN 都参与 TTA 自适应
                    if isinstance(m, nn.BatchNorm2d):
                        m.requires_grad_(True)
                        m.track_running_stats = False
                        m.running_mean = None
                        m.running_var = None

                self.optimizer.base_optimizer.zero_grad()
                self.optimizer.step(data, self.aux, self.pse)

                if stage == 1 and self.conf_thresh >= 0:
                    easy_updates += 1

            # Stage 1 结束后，根据 easy_updates 比例判断是否进入 Stage 2
            if stage == 1 and self.conf_thresh >= 0 and total_batches > 0:
                easy_ratio = easy_updates / float(total_batches)
                if easy_ratio < self.min_easy_ratio:
                    run_hard_stage = False

        # ========= Adaptation 结束后，单独做评估，不再更新模型 =========
        metrics_test = [[], [], [], []]
        self.model.eval()
        with torch.no_grad():
            for batch, data in enumerate(self.target_test_loader):
                x, y = data['data'], data['mask']
                x = torch.from_numpy(x).to(dtype=torch.float32).to(self.device)
                y = torch.from_numpy(y).to(dtype=torch.float32).to(self.device)

                pred_logit, fea = self.model(x)
                seg_output = torch.sigmoid(pred_logit)
                metrics = calculate_metrics(seg_output.detach().cpu(), y.detach().cpu())
                for i in range(len(metrics)):
                    assert isinstance(metrics[i], list), "The metrics value is not list type."
                    metrics_test[i] += metrics[i]

        test_metrics_mean = np.mean(metrics_test, axis=1)
        result = {}
        for i in range(len(test_metrics_mean)):
            result[metric_dict[i]] = test_metrics_mean[i]
        return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--aux_loss', type=str, default='ent', help='consis/ent/recon/rotate/supres/denoise')   # auxiliary loss
    parser.add_argument('--pse_loss', type=str, default='consis', help='consis/ent/recon/rotate/supres/denoise')    # pseudo loss

    parser.add_argument('--Source_Dataset', type=str,
                        help='RIM_ONE_r3/REFUGE/ORIGA/REFUGE_Valid/Drishti_GS')
                        
    parser.add_argument('--optimizer', type=str, required=False, default='Adam', help='SGD/Adam/AdamW')
    parser.add_argument('--lr', type=float, required=False, default=1e-4)
    parser.add_argument('--momentum', type=float, required=False, default=0.99)  # momentum in SGD
    parser.add_argument('--beta1', type=float, required=False, default=0.9)  # beta1 in Adam
    parser.add_argument('--beta2', type=float, required=False, default=0.999)  # beta2 in Adam.
    parser.add_argument('--weight_decay', type=float, required=False, default=0.00)
    parser.add_argument('--batch_size', type=int, required=False, default=256)
    parser.add_argument('--feat_loss_weight', type=float, required=False, default=0.0)
    parser.add_argument('--conf_thresh', type=float, required=False, default=-1.0,
                        help='entropy threshold for curriculum TTA; <0 to disable')
    parser.add_argument('--min_easy_ratio', type=float, required=False, default=0.0,
                        help='minimum ratio of high-confidence batches to enable hard-sample stage')
    
    parser.add_argument('--model_type', type=str, required=False, default='Res_Unet')
    parser.add_argument('--backbone', type=str, required=False, default='resnet34')

    parser.add_argument('--in_ch', type=int, required=False, default=3)
    parser.add_argument('--out_ch', type=int, required=False, default=2)

    parser.add_argument('--image_size', type=int, required=False, default=512)
    parser.add_argument('--num_workers', type=int, required=False, default=8)

    parser.add_argument('--path_save_model', type=str)
    parser.add_argument('--dataset_root', type=str)
    parser.add_argument('--path_save_log', type=str, required=False, default='./logs/')
    
    if torch.cuda.is_available():
        parser.add_argument('--device', type=str, required=False, default='cuda:0')
    else:
        parser.add_argument('--device', type=str, required=False, default='cpu')
    config = parser.parse_args()

    targets = ['RIM_ONE_r3', 'REFUGE', 'ORIGA', 'REFUGE_Valid', 'Drishti_GS']
    targets.remove(config.Source_Dataset)
    dice_score = 0
    for config.Target_Dataset in targets:
        TTA = TrainTTA(config)
        metric = TTA.run()
        mean_dice = (metric['Disc_Dice'] + metric['Cup_Dice']) / 2
        dice_score += mean_dice
    print(config.Source_Dataset + ': Dice Mean=' + str(dice_score / len(targets)))

